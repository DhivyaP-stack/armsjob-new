// components/Dashboard/Dashboard.tsx
//import {Header} from "../components/Header"

export const Dashboard = () => {
  return (
    <div className="min-h-screen bg-gray-100">
      {/* <Header /> */}
      <main className="p-6">
        <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
        {/* Place your dashboard cards and content here */}
      </main>
    </div>
  );
}
