// components/Dashboard/Dashboard.tsx
//import {Header} from "../components/Header"
import { OverSeasRecruitmentTable } from "./OverSeasRecruitment/OverSeasRecruitmentTables";

export const OverseasRecruitment = () => {
  return (
    <div className="min-h-screen bg-gray-100">
      {/* <Header /> */}
     <OverSeasRecruitmentTable/>
    </div>
  );
}
