export interface ManpowerSupply{
    CompanyName:string;
    EmailID:string;
    ContactPersonName:string;
    MobileNumber:string;
    OfficeLocation:string;
    CategoriesAvailable:string;
    QuantityPerCategory:string
    PreviousExperience:string;
    workedEarlierWithArms:string;
    Comments:string;
}