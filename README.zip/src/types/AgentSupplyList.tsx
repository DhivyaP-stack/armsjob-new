export interface AgentOrSupply{
    NameOfAgent:string;
    EmailID:string;
    WhatsAppNumber:string;
    MobileNumber:string;
    agentDoRecruitment:string;
    AssociatedWithArms:string;
    agentDoManpower:string;
    CategoriesYouCanSupply:string;
    QuantityEstimates:string;
    AreasCovered:string;
    AdditionalNotes:string;
}