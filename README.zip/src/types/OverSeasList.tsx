export interface OverSeasView {
    companyName:string;
    country:string;
    contactPersonName:string;
    MobileNumber:string;
    whatsupNumber:string;
    EmailId:string
    CatogoryYouCanProvide:string;
    NationalityOfWorker:string;
    MobilizationTime:string;
    UAEDeploymentExperience:string;
    AdditionalDetails:string;
   }