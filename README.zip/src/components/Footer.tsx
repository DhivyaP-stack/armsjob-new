export const Footer = () => {
    return (
      <div className="text-center py-2 bg-gray-100">
          <p className="text-xs text-armsBlack ">Copyright &copy; 2025. Arms Jobs</p>
      </div>
    )
  }
  